//: Playground - noun: a place where people can play

import UIKit


let velocidades = ["Apagado", "Baja", "Media", "Alta"]

enum Velocidades : Int {
    case Apagado = 0, Baja = 20, Media = 50, Alta = 120
    
    init( velocidadInicial : Velocidades ) {
        self = velocidadInicial
    }
}

class Auto
{
    var velocidad:Velocidades
    
    init( ) {
        velocidad = Velocidades(velocidadInicial: .Apagado)
    }
    
    func cambioDeVelocidad( ) -> ( actual : Int, velocidadEnCadena: String) {
        switch velocidad {
        case .Apagado:
            velocidad = .Baja
        case .Baja:
            velocidad = .Media
        case .Media:
            velocidad = .Alta
        case .Alta:
            velocidad = .Media
        }

        return (velocidad.rawValue, velocidades[velocidad.hashValue])
    }
}

let auto = Auto()
print("Velocidad inicial: " + "\(auto.velocidad.rawValue) km/h -> " + "(\(velocidades[auto.velocidad.hashValue]))")

for i in 0 ..< 20 {
    var cambios = auto.cambioDeVelocidad()
    print("Velocidad actual: " + "\(cambios.0) km/h -> " + "(\(cambios.1))")
}